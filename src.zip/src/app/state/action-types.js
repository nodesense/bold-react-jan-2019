// action-types.js
// action constant declaration

export const INCREMENT = "COUNTER.INCREMENT";
export const DECREMENT = "COUNTER.DECREMENT";